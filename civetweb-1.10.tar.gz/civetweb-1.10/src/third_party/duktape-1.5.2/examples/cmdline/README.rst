====================
Duktape command line
====================

Ecmascript command line execution tool, useful for running Ecmascript code
from a file, stdin, or interactively.  Also used by automatic testing.
