# Civetweb Contributors

* Abhishek Lekshmanan
* Adam Bailey
* Alan Somers
* Alex Kozlov
* bel2125
* Ben M. Ward
* BigJoe
* Bjoern Petri
* Braedy Kuzma
* brett
* Brian Lambert
* Brian Spratke
* cdbishop
* celeron55
* Charles Olivi
* Christian Mauderer
* Christopher Galas
* cjh
* Daniel Oaks
* Daniel Rempel
* Danny Al-Gaaf
* Dave Brower
* David Arnold
* David Loffredo
* Dialga
* ehlertjd
* Eric Tsau
* Erik Beran
* extergnoto
* F-Secure Corporation
* feneuilflo
* Fernando G. Aranda
* Grahack
* grenclave
* grunk
* hansipie
* HariKamath Kamath
* Henry Chang
* Jack
* Jacob Skillin
* Jan Willem Janssen
* Jeremy Lin
* Jim Evans
* jmc-
* Jochen Scheib
* Joe Mucchiello
* Joel Gallant
* Johan De Taeye
* Jordan
* Jordan Shelley
* Joshua Boyd
* Joshua D. Boyd
* kakwa
* kalphamon
* Keith Kyzivat
* Kevin Branigan
* Kevin Wojniak
* Kimmo Mustonen
* Lammert Bies
* Lawrence
* Li Peng
* Lianghui
* Maarten Fremouw
* makrsmark
* Mark Lakata
* Martin Gaida
* Mateusz Gralka
* Matt Clarkson
* mingodad
* Morgan McGuire
* mrdvlpr.xnu
* Neil Jensen
* Nick Hildebrant
* Nigel Stewart
* nihildeb
* No Face Press
* palortoff
* Patrick Drechsler
* Patrick Trinkle
* Paul Sokolovsky
* Paulo Brizolara
* pavel.pimenov
* PavelVozenilek
* Perttu Ahola
* Peter Foerster
* Philipp Friedenberger
* Philipp Hasper
* Red54
* Richard Screene
* pkvamme
* Sage Weil
* Sangwhan Moon
* Saumitra Vikram
* Scott Nations
* sgmesservey
* shantanugadgil
* Simon Hailes
* slidertom
* SpaceLord
* sunfch
* thewaterymoon
* THILMANT, Bernard
* Thomas Davis
* tnoho
* Toni Wilk
* Ulrich Hertlein
* Walt Steverson
* webxer
* William Greathouse
* xeoshow
* xtne6f
* Yehuda Sadeh

# Mongoose Contributors
CivetWeb is based on the Mongoose code.  The following users contributed to the original Mongoose release between 2010 and 2013.  This list was generated from the Mongoose GIT logs.  It does not contain contributions from the Mongoose mailing list.  There is no record for contributors prior to 2010.

* Sergey Lyubka
* Arnout Vandecappelle (Essensium/Mind)
* Benoît Amiaux
* Cody Hanson
* Colin Leitner
* Daniel Oaks
* Eric Bakan
* Erik Oomen
* Filipp Kovalev
* Ger Hobbelt
* Hendrik Polczynski
* Henrique Mendonça
* Igor Okulist
* Jay
* Joe Mucchiello
* John Safranek
* Joseph Mainwaring
* José Miguel Gonçalves
* KIU Shueng Chuan
* Katerina Blinova
* Konstantin Sorokin
* Marin Atanasov Nikolov
* Matt Healy
* Miguel Morales
* Mikhail Nikalyukin
* MikieMorales
* Mitch Hendrickson
* Nigel Stewart
* Pavel
* Pavel Khlebovich
* Rogerz Zhang
* Sebastian Reinhard
* Stefan Doehla
* Thileepan
* abadc0de
* arvidn
* bick
* ff.feng
* jmucchiello
* jwang
* lsm
* migal
* mlamb
* nullable.type
* shantanugadgil
* tayS
* test
* valenok

